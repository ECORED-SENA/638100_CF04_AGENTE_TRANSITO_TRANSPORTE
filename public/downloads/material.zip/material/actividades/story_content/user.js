function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6UFg4pXzudl":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

